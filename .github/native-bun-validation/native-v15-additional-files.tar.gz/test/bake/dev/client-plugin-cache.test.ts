import { expect } from "bun:test";
import { devTest } from "../bake-harness";
import type { Dev } from "../bake-harness";

const framework = {
  fileSystemRouterTypes: [
    {
      root: "routes",
      style: "nextjs-pages" as const,
      serverEntryPoint: "./render.ts",
      clientEntryPoint: "./client.ts",
    },
  ],
};

const manifestPlugin = `
  import { join } from 'node:path';
  import { readdir } from 'node:fs/promises';
  export default [{
    name: 'client-cache-manifest',
    setup(build) {
      const directory = join(import.meta.dirname, 'data');
      build.onResolve({ filter: /^route-names$/ }, () => ({ path: 'names', namespace: 'route-names' }));
      build.onLoad({ filter: /.*/, namespace: 'route-names' }, async () => {
        const names = (await readdir(directory)).sort().join(',');
        console.log('client-cache-manifest:' + names);
        return {
          contents: 'export default ' + JSON.stringify(names),
          loader: 'js',
          watchDirs: [directory],
        };
      });
    },
  }];
`;

function files() {
  return {
    "routes/index.ts": `export default null;`,
    "data/a.ts": `export default "first";`,
    "render.ts": `
      export function render(request, meta) {
        const scripts = meta.modules.map(path => '<script type="module" src="' + path + '"></script>').join('');
        return new Response('<!DOCTYPE html><html><body><h1></h1><button>Count 0</button>' + scripts + '</body></html>', {
          headers: { 'content-type': 'text/html' },
        });
      }
    `,
    "client.ts": `
      import names from 'route-names';
      document.querySelector('h1').textContent = names;
      console.info('client-cache-heading:' + names);
      let count = 0;
      document.querySelector('button').onclick = event => {
        event.currentTarget.textContent = 'Count ' + ++count;
      };
    `,
  };
}

async function fetchClientScripts(dev: Dev) {
  const response = await dev.fetch("/");
  expect(response.status).toBe(200);
  const html = await response.text();
  const urls = [...html.matchAll(/<script type="module" src="([^"]+)"/g)].map(match => match[1]);
  expect(urls.length).toBeGreaterThan(0);
  const scripts = await Promise.all(
    urls.map(async url => {
      const response = await dev.fetch(url);
      expect(response.status).toBe(200);
      return response.text();
    }),
  );
  return { urls, code: scripts.join("\n") };
}

function pluginOutput(dev: Dev) {
  return dev.output.lines
    .map(line => line.replace(/\x1b\[[0-9;]*m/g, ""))
    .filter(line => line.includes("client-cache-manifest:"));
}

devTest("client plugin cache probe: structural dependency update serves the current manifest", {
  framework,
  pluginFile: manifestPlugin,
  files: files(),
  async test(dev) {
    await using client = await dev.client("/", { allowUnlimitedReloads: true });
    await client.expectElemText("h1", "a.ts");
    const before = await fetchClientScripts(dev);
    expect(before.code).toContain("a.ts");
    await client.click("button");
    await dev.write("data/a.ts", `export default "second";`);
    await client.expectElemText("button", "Count 1");

    await dev.write("data/b.ts", `export default "new route";`);
    const after = await fetchClientScripts(dev);
    const observed = {
      manifestReloaded: pluginOutput(dev).some(line => line.includes("client-cache-manifest:a.ts,b.ts")),
      servedScriptHasManifest: after.code.includes("a.ts,b.ts"),
      heading: await client.elemText("h1"),
    };
    const expected = { manifestReloaded: true, servedScriptHasManifest: true, heading: "a.ts,b.ts" };
    console.log(
      "client-cache-structural",
      JSON.stringify({
        expected,
        observed,
        beforeUrls: before.urls,
        afterUrls: after.urls,
        pluginOutput: pluginOutput(dev),
      }),
    );
    expect(observed.manifestReloaded).toBe(expected.manifestReloaded);
    expect(observed.servedScriptHasManifest).toBe(expected.servedScriptHasManifest);
    await client.expectElemText("h1", expected.heading);
  },
});

devTest("client plugin cache probe: direct client entry edit serves its new heading literal", {
  framework,
  pluginFile: manifestPlugin,
  files: files(),
  async test(dev) {
    await using client = await dev.client("/", { allowUnlimitedReloads: true });
    await client.expectElemText("h1", "a.ts");
    const before = await fetchClientScripts(dev);
    expect(before.code).toContain("a.ts");
    await dev.write(
      "client.ts",
      `
      import names from 'route-names';
      document.querySelector('h1').textContent = 'DIRECT_CLIENT_EDIT:' + names;
      console.info('client-cache-heading:DIRECT_CLIENT_EDIT:' + names);
    `,
    );
    const after = await fetchClientScripts(dev);
    const observed = {
      servedScriptHasLiteral: after.code.includes("DIRECT_CLIENT_EDIT:"),
      heading: await client.elemText("h1"),
    };
    const expected = { servedScriptHasLiteral: true, heading: "DIRECT_CLIENT_EDIT:a.ts" };
    console.log(
      "client-cache-direct",
      JSON.stringify({
        expected,
        observed,
        beforeUrls: before.urls,
        afterUrls: after.urls,
        pluginOutput: pluginOutput(dev),
      }),
    );
    expect(observed.servedScriptHasLiteral).toBe(expected.servedScriptHasLiteral);
    await client.expectElemText("h1", expected.heading);
  },
});
