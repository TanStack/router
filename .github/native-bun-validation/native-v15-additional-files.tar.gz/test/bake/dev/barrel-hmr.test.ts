import { expect } from "bun:test";
import { devTest, emptyHtmlFile } from "../bake-harness";

const library = {
  "node_modules/unchanged-barrel/package.json": JSON.stringify({
    name: "unchanged-barrel",
    type: "module",
    exports: "./index.js",
    sideEffects: false,
  }),
  "node_modules/unchanged-barrel/index.js": `
    export { suffix } from './suffix.js';
    export { unused } from './unused.js';
  `,
  "node_modules/unchanged-barrel/suffix.js": `export const suffix = ':library';`,
  "node_modules/unchanged-barrel/unused.js": `export const unused = 'unused';`,
};

devTest("editing an accepted leaf does not hot-replace its unchanged barrel dependency", {
  files: {
    ...library,
    "index.html": emptyHtmlFile({ scripts: ["index.ts"], body: "<h1></h1><button>Count 0</button>" }),
    "index.ts": `
      import { suffix } from 'unchanged-barrel';
      import './leaf.ts';
      document.documentElement.dataset.suffix = suffix;
      globalThis.documentToken = Math.random();
      let count = 0;
      document.querySelector('button').onclick = event => {
        event.currentTarget.textContent = 'Count ' + ++count;
      };
    `,
    "leaf.ts": `
      import { suffix } from 'unchanged-barrel';
      document.querySelector('h1').textContent = 'BEFORE' + suffix;
      import.meta.hot.accept();
    `,
  },
  async test(dev) {
    await using c = await dev.client("/", { allowUnlimitedReloads: true });
    await c.expectElemText("h1", "BEFORE:library");
    await c.click("button");
    await c.expectElemText("button", "Count 1");
    const token = await c.js`globalThis.documentToken`;

    await dev.patch("leaf.ts", { find: "BEFORE", replace: "AFTER" });
    await c.expectElemText("h1", "AFTER:library");
    expect(await c.js`globalThis.documentToken`).toBe(token);
    await c.expectElemText("button", "Count 1");
  },
});

devTest("editing a React component preserves state when it imports an unchanged barrel", {
  framework: "react",
  files: {
    ...library,
    "index.html": emptyHtmlFile({ scripts: ["index.tsx"], body: '<div id="root"></div>' }),
    "index.tsx": `
      import { createRoot } from 'react-dom/client';
      import { suffix } from 'unchanged-barrel';
      import App from './App.tsx';
      document.documentElement.dataset.suffix = suffix;
      globalThis.documentToken = Math.random();
      createRoot(document.getElementById('root')).render(<App />);
    `,
    "App.tsx": `
      import { useState } from 'react';
      import { suffix } from 'unchanged-barrel';
      export default function App() {
        const [count, setCount] = useState(0);
        return <><h1>{'BEFORE' + suffix}</h1><button onClick={() => setCount(count + 1)}>Count {count}</button></>;
      }
    `,
  },
  async test(dev) {
    await using c = await dev.client("/", { allowUnlimitedReloads: true, storeHotChunks: true });
    await c.expectElemText("h1", "BEFORE:library");
    const html = await dev.fetch("/").text();
    const scriptUrl = [...html.matchAll(/src="([^"]+\.js)"/g)][0]?.[1];
    expect(scriptUrl).toBeDefined();
    const initialBundle = await dev.fetch(scriptUrl!).text();
    await c.click("button");
    await c.expectElemText("button", "Count 1");
    const token = await c.js`globalThis.documentToken`;

    await dev.patch("App.tsx", { find: "BEFORE", replace: "AFTER" });
    await c.expectElemText("h1", "AFTER:library");
    const chunk = await c.getMostRecentHmrChunk();
    let replacements: Record<string, unknown> = {};
    // Parse the public update packet without invoking any module factories.
    new Function("self", chunk)({
      [Symbol.for("bun:hmr")](modules: Record<string, unknown>) {
        replacements = modules;
      },
    });
    console.log("BARREL_REACT_UPDATE_KEYS " + JSON.stringify(Object.keys(replacements)));
    for (const [id, definition] of Object.entries(replacements)) {
      const after = JSON.stringify(definition, (_key, value) =>
        typeof value === "function" ? value.toString() : value,
      );
      const start = initialBundle.indexOf(JSON.stringify(id) + ":");
      console.log("BARREL_REACT_MODULE " + JSON.stringify({
        id,
        after,
        initialOffset: start,
        beforeExcerpt: start < 0 ? null : initialBundle.slice(start, start + after.length + 300),
      }));
    }
    console.log("BARREL_REACT_BROWSER_OUTPUT " + JSON.stringify(c.output.lines));
    expect(await c.js`globalThis.documentToken`).toBe(token);
    await c.expectElemText("button", "Count 1");
  },
});
